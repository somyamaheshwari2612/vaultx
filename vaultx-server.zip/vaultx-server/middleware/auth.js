const crypto = require('crypto');
const { db } = require('../db');
const passwords = require('../passwords');

const STRICT_RECIPIENT = process.env.STRICT_RECIPIENT !== 'false';
const sha256 = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');

const clientIp = (req) => (req.ip || req.socket.remoteAddress || '').replace('::ffff:', '');
const remainingViews = (f) => (f.max_downloads == null ? null : Math.max(0, f.max_downloads - f.download_count));

function fileState(f) {
  if (f.revoked) return 'revoked';
  if (f.expires_at && f.expires_at <= Date.now()) return 'expired';
  if (f.max_downloads != null && f.download_count >= f.max_downloads) return 'limit_reached';
  return 'active';
}

function logAccess(fileId, req, status, remaining) {
  db.prepare(`INSERT INTO access_logs (file_id, ts, ip, user_agent, auth_status, remaining_views)
              VALUES (?,?,?,?,?,?)`)
    .run(fileId, Date.now(), clientIp(req), req.get('user-agent') || 'unknown', status, remaining);
}

// Authorisation Middleware: expiry -> revocation -> limits -> password -> recipient
async function authorizeDownload(req, res, next) {
  try {
    const f = db.prepare('SELECT * FROM files WHERE id=?').get(req.params.id);
    if (!f) return res.status(404).json({ error: 'not_found' });

    const state = fileState(f);
    if (state !== 'active') {
      logAccess(f.id, req, 'denied_' + state, remainingViews(f));
      return res.status(410).json({ error: state, message: 'Access Denied / Self-Destructed' });
    }

    const link = db.prepare('SELECT password_hash FROM share_links WHERE file_id=?').get(f.id);
    if (link && link.password_hash) {
      const pw = req.body && req.body.password;
      const ok = pw ? await passwords.verify(link.password_hash, String(pw)) : false;
      if (!ok) {
        logAccess(f.id, req, 'denied_password', remainingViews(f));
        return res.status(401).json({ error: 'password_required_or_wrong' });
      }
    }

    if (f.share_mode === 'registered' && STRICT_RECIPIENT) {
      const rk = db.prepare('SELECT username FROM recipient_keys WHERE file_id=?').get(f.id);
      if (rk && rk.username && rk.username !== (req.body && req.body.username)) {
        logAccess(f.id, req, 'denied_not_recipient', remainingViews(f));
        return res.status(403).json({ error: 'not_recipient' });
      }
    }
    req.vaultFile = f;
    next();
  } catch (e) { next(e); }
}

// Owner-only routes (logs, revoke) - constant-time token compare
function requireOwner(req, res, next) {
  const f = db.prepare('SELECT * FROM files WHERE id=?').get(req.params.id);
  if (!f) return res.status(404).json({ error: 'not_found' });
  const token = req.query.token || req.get('x-owner-token') || '';
  const a = Buffer.from(sha256(token)), b = Buffer.from(f.owner_token_hash);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(403).json({ error: 'bad_owner_token' });
  req.vaultFile = f;
  next();
}

module.exports = { authorizeDownload, requireOwner, logAccess, fileState, remainingViews, sha256, clientIp };
